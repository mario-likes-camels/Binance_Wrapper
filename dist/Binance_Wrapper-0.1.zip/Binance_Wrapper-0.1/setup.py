from setuptools import setup

setup(name='Binance_Wrapper',
      version='0.1',
      description='The FUnctions to Make using the Binance API easier and cleaner',
      url='http://github.com/storborg/funniest',
      author='Patrick',
      author_email='Dont_Email_me.@hotmail.com',
      license='MIT',
      packages=['Binance_Wrapper'],
      zip_safe=False)